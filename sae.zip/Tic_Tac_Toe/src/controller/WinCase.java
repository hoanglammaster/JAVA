/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import model.Position;

/**
 *
 * @author hoang
 */
public class WinCase {
    private int[][]board;
    private int turn;
    private int numberOfRows;
    private String[] players;
    private final int PLAYER1 = 1;
    private final int PLAYER2 = 2;
    public WinCase() {
    }

    public WinCase(int n) {
        turn = 0;
        numberOfRows = n;
        this.board = new int[n][n];
        players =new String[] {"X","O"};
    }
    
    public String checkWin(Position position){
        if(turn%2==0){
            this.board[position.getX()][position.getY()] = PLAYER1;
        }else{
            this.board[position.getX()][position.getY()] = PLAYER2;
        }
        if(turn >4){
            if(checkRow(position)){
                return players[turn%2];
            }
             if(checkColumn(position)){
                return players[turn%2];
            }
              if(checkDiagonal(position)){
                return players[turn%2];
            }
        }
        if(turn == numberOfRows*numberOfRows-1){
            return "draw";
        }
        return "nothing";
        
    }
    
    public boolean checkRow(Position position){
        ArrayList<Integer> listValues = new ArrayList<>();
        for(int i = 0; i < numberOfRows; i ++){
            listValues.add(board[position.getX()][i]);
        }
        for(Integer values : listValues){
            if(board[position.getX()][position.getY()]!= values){
                return false;
            }
        }
        return true;
    }
    public boolean checkColumn(Position position){
        ArrayList<Integer> listValues = new ArrayList<>();
        for(int i = 0; i < numberOfRows; i ++){
            listValues.add(board[i][position.getY()]);
        }
        for(Integer values : listValues){
            if(board[position.getX()][position.getY()]!= values){
                return false;
            }
        }
        return true;
    }
    public boolean checkDiagonal(Position position){
        boolean inDiagonal = false;
        for(int i =0; i < numberOfRows; i++){
            if(position.getX()==i && position.getY()==i){
                inDiagonal = true;
            }
        }
        if(inDiagonal == false){
            for(int i =0; i < numberOfRows; i++){
            if(position.getX()==i && position.getY()==numberOfRows-i-1){
                inDiagonal = true;
            }
        }
        }
        if(inDiagonal){
            
        }else{
            return false;
        }
    }
}
