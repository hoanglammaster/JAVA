/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.ServerSocket;

/**
 *
 * @author hoang
 */
public class GameServer implements Runnable {

    private String player1, player2;
    private int port;
    private ServerSocket serverSocket;

    public GameServer(String player1, String player2, int port) {
        this.port = port;
        this.player1 = player1;
        this.player2 = player2;
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
