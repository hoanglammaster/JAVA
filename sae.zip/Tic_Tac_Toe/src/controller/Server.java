/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author hoang
 */
public class Server implements Runnable {

    private final int PORT = 3333;
    private ArrayList<String> listPlayer = new ArrayList<>();
    private ArrayList<ClientHandler> listClient = new ArrayList<>();
    @Override
    public void run() {
        try {
            ServerSocket server = new ServerSocket(PORT);
            while(true){
                Socket client = server.accept();
                ClientHandler clients = new ClientHandler(client, listPlayer, listClient);
                listClient.add(clients);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Server server = new Server();
        Thread t = new Thread(server);
        t.start();
    }

}
