/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author hoang
 */
public class ClientHandler implements Runnable {

    private Socket socket;
    private ArrayList<ClientHandler> listClientHandler;
    private ArrayList<String> listPlayer;
    private String playerName;
    private DataInputStream dataIn;
    private DataOutputStream dataOut;
    private ObjectInputStream objIn;
    private ObjectOutputStream objOut;

    public ClientHandler(Socket socket, ArrayList<String> listPlayer, ArrayList<ClientHandler> listClientHandler) {
        this.socket = socket;
        this.listPlayer = listPlayer;
        this.listClientHandler = listClientHandler;
        try {
            dataIn = new DataInputStream(socket.getInputStream());
            dataOut = new DataOutputStream(socket.getOutputStream());
            objOut = new ObjectOutputStream(socket.getOutputStream());
            objIn = new ObjectInputStream(socket.getInputStream());
            playerName = dataIn.readUTF();
            listPlayer.add(playerName);
            Thread t = new Thread(this);
            t.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                String code = dataIn.readUTF();
                System.out.println(code);
                switch (code) {
                    case "getListPlayer":
                        objOut.writeObject(listPlayer);
                        break;
//                    case "invite":
//                        String inviteName = dataIn.readUTF();
//                        boolean inviteSuccess = askToPlayer(inviteName);
                        
                }
                if(playerName.equals("Minh Huyen")){
                    listClientHandler.get(0).dataOut.writeByte(3);
                }
            } catch (IOException e) {
                listClientHandler.remove(this);
                listPlayer.remove(playerName);
                try {
                    dataIn.close();
                    dataOut.close();
                    objIn.close();
                    objOut.close();
                    socket.close();
                } catch (IOException j) {
                    j.printStackTrace();
                }
                System.out.println(playerName+" is offline");
                for(String player : listPlayer){
                    System.out.println("\t"+player);
                }
                break;
            }
        }
        
    }
//    private boolean askToPlayer(String inviteName){
//        for(ClientHandler clients : listClientHandler){
//            if(clients.getPlayerName().equals(inviteName)){
//                clients.
//            }
//        }
//    }
    public String getPlayerName(){
        return playerName;
    }

}
