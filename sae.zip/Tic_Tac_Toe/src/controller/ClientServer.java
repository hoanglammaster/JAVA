/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author hoang
 */
public class ClientServer {

    private String playerName;
    private final int PORT = 3333;
    private DataOutputStream dataOut;
    private DataInputStream dataIn;
    private ObjectInputStream objIn;
    private ObjectOutputStream objOut;
    private Socket socket;
    public ClientServer() {
    }

    public ClientServer(String playerName) {
        this.playerName = playerName;
        connectToServer();
        getConnection();
    }

    private void connectToServer() {
        try {
            socket = new Socket("localhost", PORT);
           
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void getConnection(){
        try {
            dataIn = new DataInputStream(socket.getInputStream());
            dataOut = new DataOutputStream(socket.getOutputStream());
            objIn = new ObjectInputStream(socket.getInputStream());
            objOut = new ObjectOutputStream(socket.getOutputStream());
            dataOut.writeUTF(playerName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public ArrayList<String> getListPlayer() {
        ArrayList<String> listPlayer = null;
        try {
            dataOut.writeUTF("getListPlayer");
            
            listPlayer = (ArrayList<String>)objIn.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return listPlayer;
    }
    public boolean invitePlayer(String invitePlayerName){
        boolean inviteSucess = false;
        try {
            dataOut.writeUTF("invite");
            dataOut.writeUTF(invitePlayerName);
            inviteSucess = dataIn.readBoolean();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return inviteSucess;
    }
    public DataInputStream getDataInputStream(){
        return dataIn;
    }
    
    
}
